window.onload = function()
{

//regexp
var reg = {
	mobile:/^1[3|4|5|8][0-9]\d{8}$/,
	tel:/^(\d{3,4}\d{7,8})$/,
	emailstandard:/^[a-zA-Z0-9-._]+@[a-zA-Z0-9-._]+.[a-z]{2,3}$/,
	email:/@/,
	hostname:/^[a-zA-Z0-9-._]+.[a-z]{2,3}$/,
	hostnamefirst:/^[a-zA-Z0-9-._]+$/,
	empty:/^\S+$/,
	numberextend:function(n,n2){
		if(n2 && n)
		{
			if(n && reg.number.test(n) && reg.number.test(n2))
			{
				var _reg = new RegExp("^\\d{"+n+","+n2+"}$");
				return _reg;
			}
		}
		else if(n)
		{
			if(n && reg.number.test(n))
			{
				var _reg = new RegExp("^\\d{"+n+"}$");
				return _reg;
			}	
		}else
		{
			return /^\d{1,}$/;
		}
	},
	nexdrule:/^[d]\d{1,}$/,
	nexdruleextend:/^[d]\d{1,}-\d{1,}$/,
	number:/^\d{1,}$/,
	birth:/^[1-2][0-9]\d{2}-(([0][1-9])|([1][0-2]))-([0-2][0-9])|([3][0-1])$/,
	year:/^[1-2][0-9]\d{2}$/,
	month:/^([0][1-9])|([1][0-2])$/,
	day:/^([0-2][0-9])|([3][0-1])$/,
	cnandnotnull:/^[\u4E00-\u9FA5\x00-\xff]+$/g,
	enandnotnull:/^[a-zA-Z]+$/,
	zipcode:/^[1-9][0-9]{5}$/,
	fnRegs:function($list){			
		var $list = $($list),len = $list.length,i=0,_temp="";
		for(;i<len;i++)
		{
			_temp = start.check($list.eq(i));
			if(_temp != "ok")
			{
				return "wrong";
			}
		}
		return "ok";		
	},
	fnReg:function($obj){		
		var $this = $obj,tempreg = $this.attr("reg");
		
		if(reg.nexdrule.test(tempreg))
		{
			tempreg = reg.numberextend(parseInt(tempreg.replace("d","")));
		}else if(reg.nexdruleextend.test(tempreg))
		{
			tempreg = tempreg.replace("d","").split("-");
			tempreg = reg.numberextend(parseInt(tempreg[0]),parseInt(tempreg[1]));
		}else
		{ 
			tempreg = reg[$this.attr("reg")] || new RegExp();
		}
		
		if(!tempreg.test($this.val()))
		{
			return 0;	
		}
		return "ok";	
	}
};	




//tips common
var tips = {
	$tip:"",
	$tiptext:"",
	$tipiframe:"",
	$tipclose:"",
	isclose:false
};

//spacial dom ,like namecard
var spacial = {
	namecard:{
		fncheck:function(str){
		    if($(spacial.namecard.relate).val()!=spacial.namecard.relavevalue)
		    {
		        return "ok";
		    }
			if(!spacial.namecard.ischange)
			{				
				$(spacial.namecard.relate).bind("change",function(){
					var $this = $(spacial.namecard.ownerid).addClass("wrong");
					start.check($this);
				});
				spacial.namecard.ischange = true;
			}			
			return spacial.fnCheck(str);
		},
		ownerid:"",
		relate:"",
		relavevalue:"",
		ischange:false
	},
	namecard2:{
		fncheck:function(str){
		    if($(spacial.namecard2.relate).val()!=spacial.namecard2.relavevalue)
		    {
		        return "ok";
		    }
			if(!spacial.namecard2.ischange)
			{				
				$(spacial.namecard2.relate).bind("change",function(){
					var $this = $(spacial.namecard2.ownerid).addClass("wrong");
					start.check($this);
				});
				spacial.namecard2.ischange = true;
			}			
			spacial.fnCheck(str);
		},
		ownerid:"",
		relate:"",
		relavevalue:"",
		ischange:false
	},
	fnCheck:function(str){
		if(!reg.empty.test(str))
		{
			return "请输入您的证件号码";	
		}
		var iLen,strReg;
			iLen = str.length;
			switch (iLen){
			  case 15:
				  strReg = /^\d{15}$/;
				  if (strReg.test(str)){
					  return "ok";
				  }else{
					  return "您的证件号含符号或空格。如证件中含括号，请输入英文半角()。";
				  }		
			  break;
			  case 18:
				strReg = new RegExp(/^(\d{17})(\d|[Xx])$/);
				var arrSplit = str.match(strReg);
				if(arrSplit != null){
					if(arrSplit[2] === "x"){
						return "请以大写输入证件号中的X。";
					}else{
						return "ok";
					}
				}else{
					return  "您的证件号含符号或空格。如证件中含括号，请输入英文半角()。";
				}
			  break;
			  default:
				  return "您输入的身份证件号码有误";
			  break;
			}	
	}
};

var common = {
	ie6:function(){
		if($.browser.msie && $.browser.version == "0")
		{
			return 0;
		}	
		else
		{
			return 1;	
		}
	},
	getById:function(id)
	{
		return document.getElementById(id);	
	},
	v:function(obj){
		return obj.val();
	},
	vdom:function(obj){
		return obj.value;
	},
	$$:function(id)
	{
		return $("#"+id);
	}
};




//page
var start = {
	init:function(){
		//tips
		tips.$tip = $(start.tip);
		tips.$tiptext = tips.$tip.find(start.tiptextFind);
		tips.$tipiframe = tips.$tip.find(start.tipiframeFind);
		tips.$tipclose = tips.$tip.find(start.tipclose);
		
		//all input have reg 
		$("input[reg]").each(function(){
			var $this = $(this);	
			var _sp = "";					
			$this.addClass("wrong").focus(function(){
				var _dm = $this.attr('defaultMessage');
				var _sp = $this.attr('spacial') || "";
				if(_dm!="")
				{
					if(_sp!="")
					{
						start.setSpacial(spacial[_sp],$this.attr("id"),$this.attr("relate"),$this.attr("relavevalue"));
						var _temp = spacial[_sp].fncheck($this.val());
						if(_temp != "ok")
						{
							_dm = _temp;	
						}
					}
					start.showTip($this,_dm);
				}
			}).blur(function(){	
				 start.check($this);
			});
		});
		tips.$tipclose.bind('click',function(){
			tips.$tip[0].style.display = "none";
		});
	},
	setSpacial:function(obj,a,b,c){
		obj.ownerid = "#"+a;
		obj.relate= "#"+b;
		obj.relavevalue=c;	
	},
	check:function($this){
		var _sp = $this.attr('spacial') || "";			
		  var _em = $this.attr('errorMessage');
		  if(_sp!=""){
			  	start.setSpacial(spacial[_sp],$this.attr("id"),$this.attr("relate"),$this.attr("relavevalue"));
				var _temp = spacial[_sp].fncheck($this.val());
				if(_temp != "ok")
				{
					_em = _temp;	
					start.showTip($this,_em);
					return _em;
				}	
				else
				{
					$this.removeClass("wrong");
					start.closeTip();
					return "ok";
				}
		  }		
		  else{					
			  var _re = reg.fnReg($this);
			  if(_re=="ok")
			  {  start.closeTip(); $this.removeClass("wrong");return "ok";}else
			  {
				  if(_em!="")
				  {
					  start.showTip($this,_em);
					  return _em;
				  }					
			  }
		  }	
	},
	showTip:function(obj,txt){		
		var of = obj.offset();		
		tips.$tiptext.html(txt);
		tips.$tip.css({left:of.left,top:of.top-55,display:'block'});		
		if(common.ie6()=="0")
		{
			tips.$tipiframe[0].style.width = tips.$tip.width() +"px";
		}	
	},
	closeTip:function(){
		tips.$tip[0].style.display = "none";
	},
	tip:"#tips",
	tipclose:"#tipclose",
	tiptextFind:".tip-right",
	tipiframeFind:"iframe"
};

//core
/*
	i -> index
	ci -> chlid index
*/
var $leftstep = $(".step li:not('.isclose')");
var pn = 0;
var pln = 0;

var doStep = {
	donext:function(){
		if(doStep.dostate()!="ok")
		{
			return false;	
		}	
		$("#ts").html(current.ci+"<br/>"+current.cl);
		if(current.ci < current.cl-1){
			pn++;
		}else{
			if(pln<$leftstep.length)
			{
				pln++; pn = 0;
			}
			else
			{ 
				pln = $leftstep.length-1; pn = $("."+$leftstep.eq(pln).attr("show")).not(".isclose").length;
			}
			if(pln==$leftstep.length-1)
			{
				otherAction.showoverview();				
			}
		};
		
		doStep.donowstate();
	},
	doprev:function(){
		$("#ts").html(current.ci+"<br/>"+current.cl);
		if(current.ci >0){
			pn--;
		}else{
			if(pln>0)
			{
				pln--; 
				pn = $("."+$leftstep.eq(pln).attr("show")).not(".isclose").length-1;
			}
			else
			{
				pln = 0;
				pn = 0;	
			}			
		};
		$("#ts").html((pn)+"<br/>"+pln);
		doStep.donowstate();
	},
	dostate:function(){
		var $list = current.children.eq(current.ci).find(".wrong");		
		if($list.length<1){
		}else{
			var _temp = reg.fnRegs($list);
			if(_temp != "ok"){
				return false;
			}	
		}	
		return "ok";	
	},
	donowstate:function(){
		current.index = pln;
		current.ci = pn;
		current.children = 	$("."+$leftstep.eq(pln).attr("show")).not(".isclose");
		current.cl = current.children.length;
		doStep.$globalPic[0].src = "images/step_"+current.cl+"_"+(current.ci+1)+".png";		
		doStep.resetObj(current.children,pn,true);
		doStep.resetObj($leftstep,pln);
	},
	resetObj:function($list,i,rule){
		if(rule)
		{
			$list.eq(i).css({display:'block'}).siblings(".steps").css({display:'none'});	
		}else{
			$list.eq(i).addClass("on").siblings().removeClass("on");		
		}
	},
	init:function(){
		doStep.$rbtn.bind('click',function(){
			doStep.donext();
		});	
		doStep.$lbtn.bind('click',function(){
			doStep.doprev();
		});	
		doStep.setListIndex();
	},
	$lbtn:$(".step_left"),
	$rbtn:$(".step_right"),
	$globalPic:$("#globalstep"),
	setListIndex:function(){
		$(".step li:not(.isclose)").each(function(i){
			$(this).find("span").html((i+1)+". ");						
		});
		$leftstep = $(".step li:not('.isclose')");
	}
};

//all lightbox dom
var otherAction = {
	showoverview:function(){
		//$(".mlast").addClass("on").siblings().removeClass("on");
		var $overview = $("#overview");
		$.lightBox($overview);
		if(!$overview.hasClass("isjl")){
			setTimeout(function(){
					$('#panel1').jScrollPane({dragMaxHeight:44,dragMinHeight:44,scrollbarWidth:10});
					$('#pane2').jScrollPane({dragMaxHeight:70,dragMinHeight:70,scrollbarWidth:16});			
					$(".overview-file-show .jScrollPaneTrack").css({background:"#eee"});
					$(".overview-file-show .jScrollPaneDrag").addClass("two");				
			},400);
			$overview.addClass("isjl");
		}
		pln = $leftstep.length-1;
		pn = $("."+$leftstep.eq(pln).attr("show")).not(".isclose").length;
		$overview.find(".popClose").bind("click",function(){
			doStep.doprev();	
			$(this).unbind("click");
		});
	},
	init:function(){
		$("#imptip_btn").bind("click",function(){
			$.lightBox("#overimptip");									   
		});
		$("#rule_btn").bind("click",function(){
			var $this = $("#overrule");
			$.lightBox($this);	
			if(!$this.hasClass("isjl")){
				setTimeout(function(){
					$('#panel4').jScrollPane({dragMaxHeight:70,dragMinHeight:70,scrollbarWidth:16});			
					$(".overrule-content .jScrollPaneTrack").addClass("two");	
				},400);
				$this.addClass("isjl");
			}
		});
		$("#contract_btn").bind("click",function(){
			$.lightBox("#overcontract");									   
		});
		$("#contract_btn").bind("click",function(){
			var $this = $("#overcontract");
			$.lightBox($this);	
			if(!$this.hasClass("isjl")){
				setTimeout(function(){
					$('#panel3').jScrollPane({dragMaxHeight:70,dragMinHeight:70,scrollbarWidth:16});			
					$(".overcontract-content .jScrollPaneTrack").addClass("two");	
				},400);	
				$this.addClass("isjl");
			}
		});
		$("#auto_btn").bind("click",function(){
			$.lightBox("#overauto");									   
		});
		$("#auto2_btn").bind("click",function(){
			$.lightBox("#overauto2");									   
		});
		$('#isagree_tk_yes').click(function(){ 
	$('#isagree_tk_content').css({display:'block'}); 
});
$('#isagree_tk_no').click(function(){ 
    $('#isagree_tk_content').css({display:'none'}); 
});	

$('#isAttachState_Yes').click(function(){ 
	$(".fuss").removeClass("isclose");
	$("#lfuss").css({display:'block'}); 
	doStep.setListIndex(); 
});
$('#isAttachState_No').click(function(){ 
    $(".fuss").addClass("isclose");
	$("#lfuss").css({display:'none'}); 
    doStep.setListIndex();
});	
$('.slidebox').each(function(){
	$(this).find(".showslidebox").click(function(){
		var $this = $(this);
		if($this.hasClass("off"))
		{
			$this.removeClass("off").addClass("on").parent().next(".ra_box").slideUp(100);
		}else{
			$this.removeClass("on").addClass("off").parent().siblings().find(".showactive").removeClass("off").addClass("on");
			$this.parent().next(".ra_box").slideDown(200).siblings(".ra_box").slideUp(100);
		}											 
	});			
});
	}	
};




var current = {
    index:0,
    children:$(".c-1"),
    ci:0,
	cl:$(".c-1").length
};

start.init();
doStep.init();
otherAction.init();
$('#isAttachState_Yes,#isAttachState_No').removeAttr("checked");
}


